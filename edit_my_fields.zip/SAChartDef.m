//
//  ChartDef.m
//  EditMyFields
//
//  Created by SCOTT ASHMORE on 16/02/2012.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "SAEditViewController.h"

@implementation SAChartDef

@synthesize chartHeader;
@synthesize values;
@synthesize xLabels;
@synthesize yMax;
@synthesize yMin;
@synthesize values2;
@synthesize values3;
@synthesize values4;
@synthesize plotName1;
@synthesize plotName2;
@synthesize plotName3;
@synthesize plotName4;


@end
